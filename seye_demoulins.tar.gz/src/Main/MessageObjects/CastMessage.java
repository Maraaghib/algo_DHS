package Main.MessageObjects;

import jbotsim.Node;

public class CastMessage {

    public Node fragment;

    public CastMessage(Node fragment)
    {
        this.fragment = fragment;
    }
}
