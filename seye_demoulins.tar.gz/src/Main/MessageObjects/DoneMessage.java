package Main.MessageObjects;

public class DoneMessage {
    public int f1;
    public int f2;

    public DoneMessage(int f1, int f2)
    {
        this.f1 = f1;
        this.f2 = f2;
    }
}
