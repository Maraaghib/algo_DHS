package Main.MessageObjects;

import jbotsim.Node;

public class FragMessage {

    public Node fragmentRoot;

    public FragMessage(Node root)
    {
        fragmentRoot = root;
    }
}
