package Main.MessageObjects;

public class PulseMessage {
}
