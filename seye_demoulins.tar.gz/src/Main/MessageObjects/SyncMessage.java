package Main.MessageObjects;

public class SyncMessage {
}
