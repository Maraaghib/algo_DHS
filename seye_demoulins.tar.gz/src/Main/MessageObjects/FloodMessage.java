package Main.MessageObjects;

public class FloodMessage {
    public int father;

    public FloodMessage(int father)
    {
        this.father = father;
    }
}
