package Main;

public enum States {
    DONE,
    PULSE,
    MIN,
    READY,
    CAST,
    ROUND_FINISHED
}
